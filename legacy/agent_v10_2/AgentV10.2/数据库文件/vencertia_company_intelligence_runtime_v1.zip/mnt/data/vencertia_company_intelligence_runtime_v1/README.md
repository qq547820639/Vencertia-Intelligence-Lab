# Vencertia Company Intelligence Runtime V1

This package is the first machine-validatable runtime contract connecting the existing Startup Intelligence Company Case Schema V1.4 to Vencertia A0–A10 agents.

## Files

- `company_intelligence_runtime.py` — Pydantic v2 canonical API/data contracts.
- `generate_json_schema.py` — Generates external JSON Schema from Pydantic models.
- `json_schema/` — Generated schemas for tool/API boundaries.
- `test_runtime_schema.py` — Initial deterministic invariant tests.
- `agent_protocol_v1.md` — Common A0–A10 Company Intelligence usage protocol.

## Design decisions

1. `CaseUnitRef = Company × Snapshot × Scope` is the comparison identity.
2. Canonical boundary models reject extra fields.
3. Upload/create operations carry an idempotency key.
4. Update flows support optimistic version checks.
5. Retrieval objective is explicit; there is no single global “similarity” contract.
6. Eligibility is intended to be enforced in Runtime, not overridden by an Agent.
7. Company-case evidence never becomes project evidence.
8. Contradictory claims remain contradictory until resolved.
9. Pydantic is canonical; JSON Schema is generated from it.

## Run

```bash
python generate_json_schema.py
pytest -q
```
